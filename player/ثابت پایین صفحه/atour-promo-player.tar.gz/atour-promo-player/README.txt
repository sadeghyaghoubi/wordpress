Atour Promo Player — version 1.0.0

INSTALLATION
Upload the ZIP through WordPress > Plugins > Add New > Upload Plugin, then activate.
The widget is disabled by default. In Settings > پخش‌کننده تبلیغاتی, verify the
three direct video URLs, edit the SEO advertisement text if needed, check فعال,
and save. Disable it by clearing that checkbox or deactivating the plugin.

The plugin is independent of the current theme and does not edit theme files.
Only administrators with manage_options can save its settings; WordPress Settings
API nonces protect the form. URLs accept HTTPS only. Front-end text is escaped.

BEHAVIOR
Lower-left fixed, responsive Persian widget. Order: sad.mov, moh.mov, mah.mov,
then repeat. Starts muted; browser autoplay policy may still require a click.
Pause/resume, sound toggle, close. Closing releases the video source and stops
further requests for the current page. Hidden tabs pause and do not advance the
playlist. The browser may retain bytes it buffered before the tab was hidden.
There is no hidden download loop, background worker or traffic-counter claim.
Broken videos are skipped; once all fail, playback stops until a user retry.
Each load/stall has a 30-second timeout. No third-party scripts or dependencies.

MEDIA REQUIREMENTS
Default URLs are inferred from the existing S3 endpoint and screenshot names:
https://s3.atourmovies.ir/movies/sad.mov
https://s3.atourmovies.ir/movies/moh.mov
https://s3.atourmovies.ir/movies/mah.mov
Verify successful HTTPS access and actual in-browser playback before enabling.
A .mov extension alone does not establish browser compatibility. For widest
support, use MP4 containing H.264 video and AAC audio with fast-start metadata.
If conversion is needed, upload converted files and replace the URLs in settings.
The media service should support byte ranges and send the correct Content-Type.
Ordinary video playback does not require adding broad cross-origin permissions.
Private buckets require an existing appropriate media-serving mechanism; this
plugin neither changes bucket permissions nor exposes storage credentials.
Use stable media URLs where possible. Expiring signed URLs stop working after
their expiration and need to be replaced or served through an existing renewal flow.

CACHING AND INTERNET USAGE
The player uses each configured URL exactly as supplied. It does not add changing
query parameters, bypass caches, or change media response headers. Normal browser
and CDN caching remains in effect under the existing media server policy.
Playback consumes internet data; the widget labels this and offers stop/close.
Actual traffic depends on browser buffering, range requests, skips and playback.

FILES
atour-promo-player.php — settings and safe front-end markup
assets/player.js — playback state and controls
assets/player.css — scoped responsive styling

Requires WordPress 6.0+ / PHP 7.4+. License: GPL-2.0-or-later.
