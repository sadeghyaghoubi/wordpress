(() => {
  'use strict';
  const root = document.getElementById('atour-promo-player');
  const config = window.atourPromoPlayerConfig;
  if (!root || !config || !Array.isArray(config.urls)) return;
  const urls = config.urls.filter(value => {
    try { return new URL(value).protocol === 'https:'; } catch (_) { return false; }
  });
  if (!urls.length) return;
  const video = root.querySelector('video');
  const toggle = root.querySelector('.atour-promo__toggle');
  const sound = root.querySelector('.atour-promo__sound');
  const status = root.querySelector('.atour-promo__status');
  const counter = root.querySelector('.atour-promo__counter');

  // Keep controls independent from the advertisement links.
  try {
    const destination = new URL(config.clickUrl || 'https://atourtech.ir/contact-us/');
    if (destination.protocol === 'https:') {
      const link = document.createElement('a');
      link.href = destination.href;
      link.target = '_blank';
      link.rel = 'noopener sponsored';
      link.className = 'atour-promo__visit';
      link.setAttribute('aria-label', 'مشاهده صفحه تبلیغ (در تب جدید)');
      root.querySelector('.atour-promo__media').appendChild(link);
      const copy = root.querySelector('.atour-promo__copy');
      const copyLink = link.cloneNode(false);
      copyLink.className = 'atour-promo__copy';
      while (copy.firstChild) copyLink.appendChild(copy.firstChild);
      copy.replaceWith(copyLink);
      const style = document.createElement('style');
      style.textContent = '#atour-promo-player .atour-promo__media{position:relative}#atour-promo-player .atour-promo__visit{position:absolute;inset:0;z-index:2;display:block}#atour-promo-player .atour-promo__controls{z-index:3}#atour-promo-player .atour-promo__status{pointer-events:none}#atour-promo-player .atour-promo__copy{color:inherit;text-decoration:none}#atour-promo-player a:focus-visible{outline:2px solid #b7df55;outline-offset:-3px}';
      root.appendChild(style);
    }
  } catch (_) { /* An invalid destination does not interrupt playback. */ }

  const failed = new Set();
  let index = 0;
  let generation = 0;
  let closed = false;
  let userPaused = false;
  let blocked = false;
  let loaded = false;
  let pendingAdvance = false;
  let loadTimer = null;
  let stalledTimer = null;

  const persianNumber = number => String(number).replace(/\d/g, digit => '۰۱۲۳۴۵۶۷۸۹'[digit]);
  const clearTimers = () => {
    window.clearTimeout(loadTimer);
    window.clearTimeout(stalledTimer);
    loadTimer = null;
    stalledTimer = null;
  };
  const canRun = () => !closed && !userPaused && !blocked;
  const setStatus = text => { status.textContent = text; };
  const updateControls = () => {
    const paused = video.paused || blocked || userPaused;
    toggle.textContent = paused ? 'پخش' : 'توقف';
    toggle.setAttribute('aria-label', paused ? 'شروع پخش' : 'توقف پخش');
    toggle.title = paused ? 'شروع پخش' : 'توقف پخش';
    sound.textContent = video.muted ? 'بی‌صدا' : 'با صدا';
    sound.setAttribute('aria-pressed', String(!video.muted));
    sound.setAttribute('aria-label', video.muted ? 'روشن کردن صدا' : 'خاموش کردن صدا');
    sound.title = video.muted ? 'روشن کردن صدا' : 'خاموش کردن صدا';
  };
  const release = () => {
    clearTimers();
    generation += 1;
    video.pause();
    video.removeAttribute('src');
    video.load();
    loaded = false;
  };
  const nextAvailable = from => {
    for (let step = 1; step <= urls.length; step += 1) {
      const candidate = (from + step) % urls.length;
      if (!failed.has(candidate)) return candidate;
    }
    return -1;
  };
  const stopForFailure = () => {
    release();
    userPaused = true;
    setStatus('پخش ویدئوها ممکن نیست. برای تلاش دوباره «پخش» را بزنید.');
    updateControls();
  };
  const handleFailure = () => {
    if (closed || !loaded) return;
    failed.add(index);
    clearTimers();
    const next = nextAvailable(index);
    if (next < 0) {
      stopForFailure();
    } else if (canRun()) {
      start(next);
    } else {
      pendingAdvance = true;
      video.pause();
      setStatus('ویدئو در دسترس نیست؛ در ادامه ویدئوی بعدی پخش می‌شود.');
      updateControls();
    }
  };
  const play = () => {
    if (!canRun() || !loaded) return;
    const token = generation;
    if (video.readyState < 3 && loadTimer === null) {
      loadTimer = window.setTimeout(() => {
        if (token === generation && canRun()) handleFailure();
      }, 30000);
    }
    const promise = video.play();
    if (promise && typeof promise.catch === 'function') {
      promise.catch(error => {
        if (token !== generation || closed || userPaused) return;
        if (error.name === 'NotSupportedError') {
          handleFailure();
        } else if (error.name !== 'AbortError') {
          blocked = true;
          clearTimers();
          setStatus('برای شروع ویدئو «پخش» را بزنید.');
          updateControls();
        }
      });
    }
  };
  const start = next => {
    if (!canRun()) { pendingAdvance = true; return; }
    clearTimers();
    generation += 1;
    index = next;
    pendingAdvance = false;
    loaded = true;
    video.src = urls[index];
    counter.textContent = `${persianNumber(index + 1)} / ${persianNumber(urls.length)}`;
    setStatus('در حال بارگذاری…');
    video.load();
    const token = generation;
    loadTimer = window.setTimeout(() => {
      if (token === generation && canRun()) handleFailure();
    }, 30000);
    play();
    updateControls();
  };
  const advance = () => {
    const next = nextAvailable(index);
    if (next < 0) stopForFailure();
    else start(next);
  };

  video.muted = true;
  video.defaultMuted = true;
  video.addEventListener('playing', () => {
    clearTimers();
    setStatus('');
    updateControls();
  });
  video.addEventListener('pause', updateControls);
  video.addEventListener('volumechange', updateControls);
  video.addEventListener('error', handleFailure);
  video.addEventListener('ended', () => {
    clearTimers();
    if (canRun()) advance();
    else pendingAdvance = true;
  });
  video.addEventListener('waiting', () => {
    if (!canRun() || !loaded) return;
    setStatus('در حال بارگذاری…');
    window.clearTimeout(stalledTimer);
    const token = generation;
    stalledTimer = window.setTimeout(() => {
      if (token === generation && canRun()) handleFailure();
    }, 30000);
  });
  toggle.addEventListener('click', () => {
    if (closed) return;
    if (!video.paused && !userPaused && !blocked) {
      userPaused = true;
      clearTimers();
      video.pause();
      setStatus('پخش متوقف است');
    } else {
      userPaused = false;
      blocked = false;
      if (failed.size === urls.length) {
        failed.clear();
        start(0);
      } else if (pendingAdvance) {
        advance();
      } else if (!loaded) {
        start(index);
      } else {
        setStatus('');
        play();
      }
    }
    updateControls();
  });
  sound.addEventListener('click', () => {
    video.muted = !video.muted;
    updateControls();
  });
  root.querySelector('.atour-promo__close').addEventListener('click', () => {
    closed = true;
    release();
    root.hidden = true;
  });
  document.addEventListener('visibilitychange', () => {
    if (closed) return;
    if (!document.hidden && canRun()) {
      if (pendingAdvance) advance();
      else if (!loaded) start(index);
      else play();
    }
  });
  window.addEventListener('pagehide', () => { clearTimers(); video.pause(); });
  window.addEventListener('pageshow', event => {
    if (event.persisted && canRun()) play();
  });
  root.hidden = false;
  updateControls();
  start(0);
})();
