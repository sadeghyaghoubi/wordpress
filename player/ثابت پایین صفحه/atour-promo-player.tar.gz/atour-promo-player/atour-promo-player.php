<?php
/**
 * Plugin Name: Atour Promo Player
 * Description: پخش‌کننده تبلیغاتی ثابت با فهرست پخش ویدئو و متن قابل تنظیم.
 * Version: 1.1.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: Atour Movies
 * License: GPL-2.0-or-later
 */

if (!defined('ABSPATH')) {
    exit;
}

final class Atour_Promo_Player {
    const OPTION = 'atour_promo_player_options';
    const VERSION = '1.1.0';

    public static function defaults() {
        return array(
            'enabled' => 0,
            'click_url' => 'https://atourtech.ir/contact-us/',
            'title' => 'سئو را کاربردی یاد بگیرید',
            'message' => 'از تحقیق کلمات کلیدی تا بهینه‌سازی سایت؛ قدم‌به‌قدم در نتایج گوگل دیده شوید.',
            'urls' => array(
                'https://s3.atourmovies.ir/movies/sad.mov',
                'https://s3.atourmovies.ir/movies/moh.mov',
                'https://s3.atourmovies.ir/movies/mah.mov',
            ),
        );
    }

    public static function options() {
        $stored = get_option(self::OPTION, array());
        return wp_parse_args(is_array($stored) ? $stored : array(), self::defaults());
    }

    public static function boot() {
        add_action('admin_menu', array(__CLASS__, 'menu'));
        add_action('admin_init', array(__CLASS__, 'register'));
        add_action('wp_enqueue_scripts', array(__CLASS__, 'assets'));
        add_action('wp_footer', array(__CLASS__, 'render'));
    }

    public static function menu() {
        add_options_page('پخش‌کننده تبلیغاتی آتور', 'پخش‌کننده تبلیغاتی', 'manage_options', 'atour-promo-player', array(__CLASS__, 'settings_page'));
    }

    public static function register() {
        register_setting('atour_promo_player', self::OPTION, array(
            'type' => 'array',
            'sanitize_callback' => array(__CLASS__, 'sanitize'),
            'default' => self::defaults(),
            'show_in_rest' => false,
        ));
    }

    public static function sanitize($input) {
        $input = is_array($input) ? $input : array();
        $urls = array();
        $raw_urls = isset($input['urls']) ? $input['urls'] : array();
        $lines = is_string($raw_urls) ? preg_split('/\R/u', $raw_urls) : (is_array($raw_urls) ? $raw_urls : array());
        foreach (array_slice($lines, 0, 20) as $line) {
            if (!is_string($line)) {
                continue;
            }
            $line = trim($line);
            if ($line === '') {
                continue;
            }
            $url = esc_url_raw($line, array('https'));
            if ($url && wp_parse_url($url, PHP_URL_SCHEME) === 'https' && wp_parse_url($url, PHP_URL_HOST)) {
                $urls[] = $url;
            } else {
                add_settings_error(self::OPTION, 'atour_invalid_url', 'نشانی نامعتبر کنار گذاشته شد. برای هر ویدئو یک نشانی کامل HTTPS وارد کنید.');
            }
        }
        $enabled = empty($input['enabled']) ? 0 : 1;
        if ($enabled && !$urls) {
            $enabled = 0;
            add_settings_error(self::OPTION, 'atour_missing_url', 'برای فعال‌کردن پخش‌کننده، دست‌کم یک نشانی ویدئو لازم است.');
        }
        return array(
            'enabled' => $enabled,
            'click_url' => esc_url_raw(isset($input['click_url']) && is_string($input['click_url']) ? $input['click_url'] : '', array('https')),
            'title' => sanitize_text_field(isset($input['title']) && is_string($input['title']) ? $input['title'] : ''),
            'message' => sanitize_textarea_field(isset($input['message']) && is_string($input['message']) ? $input['message'] : ''),
            'urls' => array_values(array_unique($urls)),
        );
    }

    public static function settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        $settings = self::options();
        ?>
        <div class="wrap" dir="rtl">
            <h1>پخش‌کننده تبلیغاتی آتور</h1>
            <?php settings_errors(self::OPTION); ?>
            <p>پخش‌کننده ثابت در پایینِ سمت چپ سایت، ویدئوها را به‌ترتیب و با صدای خاموش پخش می‌کند.</p>
            <form action="options.php" method="post">
                <?php settings_fields('atour_promo_player'); ?>
                <table class="form-table" role="presentation">
                    <tr><th scope="row">نمایش در سایت</th><td><label><input name="<?php echo esc_attr(self::OPTION); ?>[enabled]" type="checkbox" value="1" <?php checked(!empty($settings['enabled'])); ?>> فعال</label></td></tr>
                    <tr><th scope="row"><label for="atour-click-url">نشانی مقصد تبلیغ</label></th><td><input class="regular-text code" dir="ltr" id="atour-click-url" name="<?php echo esc_attr(self::OPTION); ?>[click_url]" type="url" value="<?php echo esc_attr($settings['click_url']); ?>"><p class="description">نشانی کامل HTTPS؛ با کلیک روی تصویر یا متن تبلیغ در تب جدید باز می‌شود.</p></td></tr>
                    <tr><th scope="row"><label for="atour-title">عنوان تبلیغ</label></th><td><input class="regular-text" id="atour-title" name="<?php echo esc_attr(self::OPTION); ?>[title]" type="text" value="<?php echo esc_attr($settings['title']); ?>"></td></tr>
                    <tr><th scope="row"><label for="atour-message">متن تبلیغ</label></th><td><textarea class="large-text" rows="3" id="atour-message" name="<?php echo esc_attr(self::OPTION); ?>[message]"><?php echo esc_textarea($settings['message']); ?></textarea></td></tr>
                    <tr><th scope="row"><label for="atour-urls">نشانی ویدئوها</label></th><td>
                        <textarea class="large-text code" dir="ltr" rows="6" id="atour-urls" name="<?php echo esc_attr(self::OPTION); ?>[urls]"><?php echo esc_textarea(implode("\n", (array) $settings['urls'])); ?></textarea>
                        <p class="description">هر خط یک نشانی مستقیم HTTPS؛ ترتیب خط‌ها، ترتیب پخش است. حداکثر ۲۰ ویدئو. از نشانی دائمیِ قابل‌پخش در مرورگر استفاده کنید.</p>
                    </td></tr>
                </table>
                <p>ویدئوها با همان نشانی واردشده پخش می‌شوند و کش عادی مرورگر و سرور حفظ می‌شود. افزونه تنظیمات سرور یا دسترسی فایل‌ها را تغییر نمی‌دهد.</p>
                <p>پخش آنلاین اینترنت مصرف می‌کند. بازدیدکننده می‌تواند پخش را متوقف کند، صدا را روشن کند یا پخش‌کننده را ببندد. تغییر تب، پخش را از سمت افزونه متوقف نمی‌کند؛ محدودیت‌های مرورگر ممکن است روی پخش پس‌زمینه اثر بگذارند.</p>
                <?php submit_button('ذخیره تنظیمات'); ?>
            </form>
        </div>
        <?php
    }

    private static function should_render() {
        $settings = self::options();
        return !is_admin() && !is_feed() && !is_embed() && !empty($settings['enabled']) && !empty($settings['urls']);
    }

    public static function assets() {
        if (!self::should_render()) {
            return;
        }
        wp_enqueue_style('atour-promo-player', plugin_dir_url(__FILE__) . 'assets/player.css', array(), self::VERSION);
        wp_enqueue_script('atour-promo-player', plugin_dir_url(__FILE__) . 'assets/player.js', array(), self::VERSION, true);
        $settings = self::options();
        wp_add_inline_script('atour-promo-player', 'window.atourPromoPlayerConfig = ' . wp_json_encode(array('urls' => array_values((array) $settings['urls']), 'clickUrl' => $settings['click_url']), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) . ';', 'before');
    }

    public static function render() {
        if (!self::should_render()) {
            return;
        }
        $settings = self::options();
        ?>
        <aside id="atour-promo-player" class="atour-promo" dir="rtl" aria-label="تبلیغ ویدئویی" hidden>
            <button class="atour-promo__close" type="button" aria-label="بستن تبلیغ" title="بستن تبلیغ">×</button>
            <div class="atour-promo__media">
                <video class="atour-promo__video" muted playsinline preload="none" aria-label="ویدئوی تبلیغاتی"></video>
                <div class="atour-promo__controls">
                    <button class="atour-promo__toggle" type="button" aria-label="توقف پخش" title="توقف پخش">توقف</button>
                    <span class="atour-promo__counter" aria-label="شماره ویدئو"></span>
                    <button class="atour-promo__sound" type="button" aria-label="روشن کردن صدا" title="روشن کردن صدا" aria-pressed="false">بی‌صدا</button>
                </div>
                <div class="atour-promo__status" role="status" aria-live="polite"></div>
            </div>
            <div class="atour-promo__copy">
                <span class="atour-promo__badge">آموزش سئو</span>
                <strong class="atour-promo__title"><?php echo esc_html($settings['title']); ?></strong>
                <p class="atour-promo__message"><?php echo esc_html($settings['message']); ?></p>
                <span class="atour-promo__notice">پخش آنلاین • مصرف اینترنت</span>
            </div>
        </aside>
        <?php
    }
}

Atour_Promo_Player::boot();
